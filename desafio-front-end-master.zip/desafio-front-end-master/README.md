## Instalación Local

clonar el proyecto

### `git clone https://github.com/RorrinHo/desafio-front-end.git`

En la raiz del proyecto ejecutar:

### `npm install`

Ejecutar el Servidor:

### `npm start`

Correr la app Local.<br>
Abrir [http://localhost:3000](http://localhost:3000) en el navegador.
