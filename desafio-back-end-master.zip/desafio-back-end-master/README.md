## Instalación Local

clonar el proyecto

### `git clone https://github.com/RorrinHo/desafio-back-end.git`

En la raiz del proyecto ejecutar:

### `npm install`

Ejecutar el Servidor:

### `npm start`

Correr la app Local.<br>
Abrir [http://localhost:8181](http://localhost:8181) en el navegador.


## Instalación Local Redis (Windows)

Descargar redis:

Abrir [https://github.com/MSOpenTech/redis/releases/download/win-3.2.100/Redis-x64-3.2.100.zip](https://github.com/MSOpenTech/redis/releases/download/win-3.2.100/Redis-x64-3.2.100.zip) en el navegador.

Descomprimir y agregar variable de entorno a la raiz de redis 

Ejemplo C:\Redis

Ejecutar: redis-server.exe

